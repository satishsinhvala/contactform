<?php
    $pageId = "Gems-stone";
    $pageTitle = "Gems Stone";
    require_once 'inc/header.php';
?>

<section class="page-heding-bx" style="background-image: url(/img/bg-about.jpg);">
<!--  pagenavigationbar start  -->
<div class="custom-container pagenavigationbar">
    <p><a href="/">Home</a><span><i class="fa fa-angle-right" aria-hidden="true"></i></span><a class="active" href="javascript:void(0);">May Birthstone</a></p>
</div>
<!--  pagenavigationbar end  -->
    <h3 class="page-h3">May Birthstone</h3>
</section>

<section class="pt-3 pb-5">
    <div class="container-lg mt-4 px-sm-4 px-2">
        <div class="product-slider owl-carousel owl-theme" id="hbdfhbdfrxh">

            <div class="product-bx">
                <a href="/detail">
                    <div class="product-bx-img" style="background-image: url('/img/gems1.jpg');">
                        <img src="/img/gems.jpg" alt="">
                        <!-- <span class="discount-bx">-10%</span> -->
                        <div class="hot-stock-bx">
                            <span class="tagname-bx">Hot</span>
                            <!-- <span class="stock-bx">Out of Stock</span> -->
                        </div>
                    </div>
                </a>
                <div class="other-links">
                    <span><svg xmlns="http://www.w3.org/2000/svg" width="100" height="100" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="feather feather-shopping-bag"><path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"></path><line x1="3" y1="6" x2="21" y2="6"></line><path d="M16 10a4 4 0 0 1-8 0"></path></svg></span>
                    <span><svg xmlns="http://www.w3.org/2000/svg" width="100" height="100" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="feather feather-heart"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"></path></svg></span>
                    <span><svg xmlns="http://www.w3.org/2000/svg" width="100" height="100" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="feather feather-search"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg></span>
                </div>
                <a href="/detail">
                    <div class="product-bx-text">
                        <div class="start-rating-bx">
                            <div class="start-bx">
                                <svg class="active" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M480 208H308L256 48l-52 160H32l140 96-54 160 138-100 138 100-54-160z" fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="32"/></svg>
                                <svg class="active" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M480 208H308L256 48l-52 160H32l140 96-54 160 138-100 138 100-54-160z" fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="32"/></svg>
                                <svg class="active" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M480 208H308L256 48l-52 160H32l140 96-54 160 138-100 138 100-54-160z" fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="32"/></svg>
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M480 208H308L256 48l-52 160H32l140 96-54 160 138-100 138 100-54-160z" fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="32"/></svg>
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M480 208H308L256 48l-52 160H32l140 96-54 160 138-100 138 100-54-160z" fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="32"/></svg>
                            </div>
                            <span class="rating-num">(10 review)</span>
                        </div>
                        <h6 class="product-hed">Stone Name Here</h6>
                        <div class="price-bx">
                            <p class="del-price"><span>$</span>1250</p>
                            <!-- <p><span>$</span>127.6 - </p> -->
                            <p><span>$</span>125.25</p>
                        </div>

                    </div>
                </a>
            </div>

            <div class="product-bx">
                <a href="/detail">
                    <div class="product-bx-img" style="background-image: url('/img/gems2.jpg');">
                        <img src="/img/gems1.jpg" alt="">
                        <!-- <span class="discount-bx">-10%</span> -->
                        <div class="hot-stock-bx">
                            <!-- <span class="tagname-bx">Hot</span> -->
                            <!-- <span class="stock-bx">Out of Stock</span> -->
                        </div>
                    </div>
                </a>
                <div class="other-links">
                    <span><svg xmlns="http://www.w3.org/2000/svg" width="100" height="100" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="feather feather-shopping-bag"><path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"></path><line x1="3" y1="6" x2="21" y2="6"></line><path d="M16 10a4 4 0 0 1-8 0"></path></svg></span>
                    <span><svg xmlns="http://www.w3.org/2000/svg" width="100" height="100" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="feather feather-heart"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"></path></svg></span>
                    <span><svg xmlns="http://www.w3.org/2000/svg" width="100" height="100" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="feather feather-search"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg></span>
                </div>
                <a href="/detail">
                    <div class="product-bx-text">
                        <div class="start-rating-bx">
                            <div class="start-bx">
                                <svg class="active" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M480 208H308L256 48l-52 160H32l140 96-54 160 138-100 138 100-54-160z" fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="32"/></svg>
                                <svg class="active" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M480 208H308L256 48l-52 160H32l140 96-54 160 138-100 138 100-54-160z" fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="32"/></svg>
                                <svg class="active" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M480 208H308L256 48l-52 160H32l140 96-54 160 138-100 138 100-54-160z" fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="32"/></svg>
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M480 208H308L256 48l-52 160H32l140 96-54 160 138-100 138 100-54-160z" fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="32"/></svg>
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M480 208H308L256 48l-52 160H32l140 96-54 160 138-100 138 100-54-160z" fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="32"/></svg>
                            </div>
                            <span class="rating-num">(10 review)</span>
                        </div>
                        <h6 class="product-hed">Stone Name Here</h6>
                        <div class="price-bx">
                            <!-- <p class="del-price"><span>$</span>1250</p> -->
                            <!-- <p><span>$</span>127.6 - </p> -->
                            <p><span>$</span>125.25</p>
                        </div>

                    </div>
                </a>
            </div>

            <div class="product-bx">
                <a href="/detail">
                    <div class="product-bx-img" style="background-image: url('/img/gems3.jpg');">
                        <img src="/img/gems2.jpg" alt="">
                        <!-- <span class="discount-bx">-10%</span> -->
                        <div class="hot-stock-bx">
                            <span class="tagname-bx">Hot</span>
                            <!-- <span class="stock-bx">Out of Stock</span> -->
                        </div>
                    </div>
                </a>
                <div class="other-links">
                    <span><svg xmlns="http://www.w3.org/2000/svg" width="100" height="100" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="feather feather-shopping-bag"><path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"></path><line x1="3" y1="6" x2="21" y2="6"></line><path d="M16 10a4 4 0 0 1-8 0"></path></svg></span>
                    <span><svg xmlns="http://www.w3.org/2000/svg" width="100" height="100" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="feather feather-heart"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"></path></svg></span>
                    <span><svg xmlns="http://www.w3.org/2000/svg" width="100" height="100" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="feather feather-search"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg></span>
                </div>
                <a href="/detail">
                    <div class="product-bx-text">
                        <div class="start-rating-bx">
                            <div class="start-bx">
                                <svg class="active" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M480 208H308L256 48l-52 160H32l140 96-54 160 138-100 138 100-54-160z" fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="32"/></svg>
                                <svg class="active" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M480 208H308L256 48l-52 160H32l140 96-54 160 138-100 138 100-54-160z" fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="32"/></svg>
                                <svg class="active" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M480 208H308L256 48l-52 160H32l140 96-54 160 138-100 138 100-54-160z" fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="32"/></svg>
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M480 208H308L256 48l-52 160H32l140 96-54 160 138-100 138 100-54-160z" fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="32"/></svg>
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M480 208H308L256 48l-52 160H32l140 96-54 160 138-100 138 100-54-160z" fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="32"/></svg>
                            </div>
                            <span class="rating-num">(10 review)</span>
                        </div>
                        <h6 class="product-hed">Stone Name Here</h6>
                        <div class="price-bx">
                            <!-- <p class="del-price"><span>$</span>1250</p> -->
                            <!-- <p><span>$</span>127.6 - </p> -->
                            <p><span>$</span>125.25</p>
                        </div>

                    </div>
                </a>
            </div>

            <div class="product-bx">
                <a href="/detail">
                    <div class="product-bx-img" style="background-image: url('/img/gems.jpg');">
                        <img src="/img/gems1.jpg" alt="">
                        <!-- <span class="discount-bx">-10%</span> -->
                        <div class="hot-stock-bx">
                            <!-- <span class="tagname-bx">Hot</span> -->
                            <!-- <span class="stock-bx">Out of Stock</span> -->
                        </div>
                    </div>
                </a>
                <div class="other-links">
                    <span><svg xmlns="http://www.w3.org/2000/svg" width="100" height="100" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="feather feather-shopping-bag"><path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"></path><line x1="3" y1="6" x2="21" y2="6"></line><path d="M16 10a4 4 0 0 1-8 0"></path></svg></span>
                    <span><svg xmlns="http://www.w3.org/2000/svg" width="100" height="100" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="feather feather-heart"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"></path></svg></span>
                    <span><svg xmlns="http://www.w3.org/2000/svg" width="100" height="100" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="feather feather-search"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg></span>
                </div>
                <a href="/detail">
                    <div class="product-bx-text">
                        <div class="start-rating-bx">
                            <div class="start-bx">
                                <svg class="active" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M480 208H308L256 48l-52 160H32l140 96-54 160 138-100 138 100-54-160z" fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="32"/></svg>
                                <svg class="active" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M480 208H308L256 48l-52 160H32l140 96-54 160 138-100 138 100-54-160z" fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="32"/></svg>
                                <svg class="active" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M480 208H308L256 48l-52 160H32l140 96-54 160 138-100 138 100-54-160z" fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="32"/></svg>
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M480 208H308L256 48l-52 160H32l140 96-54 160 138-100 138 100-54-160z" fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="32"/></svg>
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M480 208H308L256 48l-52 160H32l140 96-54 160 138-100 138 100-54-160z" fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="32"/></svg>
                            </div>
                            <span class="rating-num">(10 review)</span>
                        </div>
                        <h6 class="product-hed">Stone Name Here</h6>
                        <div class="price-bx">
                            <!-- <p class="del-price"><span>$</span>1250</p> -->
                            <!-- <p><span>$</span>127.6 - </p> -->
                            <p><span>$</span>125.25</p>
                        </div>

                    </div>
                </a>
            </div>

            <div class="product-bx">
                <a href="/detail">
                    <div class="product-bx-img" style="background-image: url('/img/gems1.jpg');">
                        <img src="/img/gems2.jpg" alt="">
                        <!-- <span class="discount-bx">-10%</span> -->
                        <div class="hot-stock-bx">
                            <!-- <span class="tagname-bx">Hot</span> -->
                            <!-- <span class="stock-bx">Out of Stock</span> -->
                        </div>
                    </div>
                </a>
                <div class="other-links">
                    <span><svg xmlns="http://www.w3.org/2000/svg" width="100" height="100" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="feather feather-shopping-bag"><path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"></path><line x1="3" y1="6" x2="21" y2="6"></line><path d="M16 10a4 4 0 0 1-8 0"></path></svg></span>
                    <span><svg xmlns="http://www.w3.org/2000/svg" width="100" height="100" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="feather feather-heart"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"></path></svg></span>
                    <span><svg xmlns="http://www.w3.org/2000/svg" width="100" height="100" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="feather feather-search"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg></span>
                </div>
                <a href="/detail">
                    <div class="product-bx-text">
                        <div class="start-rating-bx">
                            <div class="start-bx">
                                <svg class="active" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M480 208H308L256 48l-52 160H32l140 96-54 160 138-100 138 100-54-160z" fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="32"/></svg>
                                <svg class="active" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M480 208H308L256 48l-52 160H32l140 96-54 160 138-100 138 100-54-160z" fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="32"/></svg>
                                <svg class="active" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M480 208H308L256 48l-52 160H32l140 96-54 160 138-100 138 100-54-160z" fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="32"/></svg>
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M480 208H308L256 48l-52 160H32l140 96-54 160 138-100 138 100-54-160z" fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="32"/></svg>
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M480 208H308L256 48l-52 160H32l140 96-54 160 138-100 138 100-54-160z" fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="32"/></svg>
                            </div>
                            <span class="rating-num">(10 review)</span>
                        </div>
                        <h6 class="product-hed">Stone Name Here</h6>
                        <div class="price-bx">
                            <!-- <p class="del-price"><span>$</span>1250</p> -->
                            <!-- <p><span>$</span>127.6 - </p> -->
                            <p><span>$</span>125.25</p>
                        </div>

                    </div>
                </a>
            </div>

        </div>
    </div>
</section>

<section class="container-lg mt-5 mb-5 legal-main px-3 px-sm-5">
    <div>
        <div class="row justify-content-center align-items-center">
            <div class="col-lg-4 col-md-6 mb-4">
                <img class="stone-gems-img" src="/img/gems-stone/garnet.png" alt="">
            </div>
            <div class="col-lg-8 col-md-6 mb-4">
                <h4 style='font-family: "Lato",sans-serif;font-size: 36px;'>Emerald</h4>
                <h5>Introduction</h5>
                <p>Emerald is the birthstone for the month of May. One of the 3 basic stones. It is a green to a greenish-blue variety of beryl. Relatively softer as per Moh's hardness
                scale -9 . The difference in the degree of green makes one stone emerald and the other less expensive green Beryl.</p>
            </div>
        </div>


        <h5>Emerald history</h5>
        <p>The first-ever known emerald mines were in Egypt, dating from at least 330 BC into the 1700s.</p>
        <p>Cleopatra had a passion for emerald and used it in all her royal adornments. Emeralds were used by the Incas in their jewelry and religious ceremonies for over
        500 years. The gem was traded by the Spanish for precious metals. Their trades opened the eyes of European and Asian royalty to emerald’s majesty.
        </p>

        <h5>Colour</h5>
        <p>People desire emeralds of color varying from bluish green to pure green with vivid color saturation.</p>

        <h5>Clarity</h5>
        <p>In emerald, the clarity is tested by what traders like to call Jardin or garden. Most emeralds are badly flawed , virtually opaque, merely green bodycolor but no life.
        Most of the Emerald in the Markets are heat-treated, immersed in Oil to enhance the color & clarity.</p>

        <h5>Cut</h5>
        <p>Emeralds are usually cut as rectangular step cuts called Emerald cuts due to the crystal shape.</p>

        <h5>Carat weight</h5>
        <p>Due to the carat weight, emeralds appear larger in size than one-carat diamonds.</p>
        <p>Value is greatly determined by the area where it is mined. Emerald is Colombia , Muzo mine</p>

        <h5>Healing properties</h5>
        <p>Emeralds enhance love, unity, and friendship. It also has the ability to maintain partnership and also signifies unfaithfulness by changing color. It helps in balancing
        the heart chakra and also has a healing effect on the emotions and the physical heart.</p>
        <p>Other green stones often confused with Emeralds are Synthetic Emeralds developed with Hydrothermal Process ; Flux Process ; Flame fusion way. lot of Assembled
        emeralds are also available in the Market. Top will be Natural and the bottom will be synthetic glued from the center. Known as Doublet or Triplet.
        Always get your stone checked by an authenticated Gem testing Lab before making a big Purchase.</p>

        <h5>Conclusion</h5>
        <p>Emeralds are gemstones that are usually given as gifts by spouses on their 20th anniversary. Check out our website to find out more about what we have in store for
        you.</p>
    </div>
</section>


<?php
    require_once 'inc/footer.php';
?>