<?php
    $pageId = "Gems-stone";
    $pageTitle = "Gems Stone";
    require_once 'inc/header.php';
?>

<section class="page-heding-bx" style="background-image: url(/img/bg-about.jpg);">
<!--  pagenavigationbar start  -->
<div class="custom-container pagenavigationbar">
    <p><a href="/">Home</a><span><i class="fa fa-angle-right" aria-hidden="true"></i></span><a class="active" href="javascript:void(0);">April Birthstone</a></p>
</div>
<!--  pagenavigationbar end  -->
    <h3 class="page-h3">April Birthstone</h3>
</section>

<section class="pt-3 pb-5">
    <div class="container-lg mt-4 px-sm-4 px-2">
        <div class="product-slider owl-carousel owl-theme" id="hbdfhbdfrxh">

            <div class="product-bx">
                <a href="/detail">
                    <div class="product-bx-img" style="background-image: url('/img/gems1.jpg');">
                        <img src="/img/gems.jpg" alt="">
                        <!-- <span class="discount-bx">-10%</span> -->
                        <div class="hot-stock-bx">
                            <span class="tagname-bx">Hot</span>
                            <!-- <span class="stock-bx">Out of Stock</span> -->
                        </div>
                    </div>
                </a>
                <div class="other-links">
                    <span><svg xmlns="http://www.w3.org/2000/svg" width="100" height="100" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="feather feather-shopping-bag"><path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"></path><line x1="3" y1="6" x2="21" y2="6"></line><path d="M16 10a4 4 0 0 1-8 0"></path></svg></span>
                    <span><svg xmlns="http://www.w3.org/2000/svg" width="100" height="100" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="feather feather-heart"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"></path></svg></span>
                    <span><svg xmlns="http://www.w3.org/2000/svg" width="100" height="100" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="feather feather-search"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg></span>
                </div>
                <a href="/detail">
                    <div class="product-bx-text">
                        <div class="start-rating-bx">
                            <div class="start-bx">
                                <svg class="active" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M480 208H308L256 48l-52 160H32l140 96-54 160 138-100 138 100-54-160z" fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="32"/></svg>
                                <svg class="active" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M480 208H308L256 48l-52 160H32l140 96-54 160 138-100 138 100-54-160z" fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="32"/></svg>
                                <svg class="active" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M480 208H308L256 48l-52 160H32l140 96-54 160 138-100 138 100-54-160z" fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="32"/></svg>
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M480 208H308L256 48l-52 160H32l140 96-54 160 138-100 138 100-54-160z" fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="32"/></svg>
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M480 208H308L256 48l-52 160H32l140 96-54 160 138-100 138 100-54-160z" fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="32"/></svg>
                            </div>
                            <span class="rating-num">(10 review)</span>
                        </div>
                        <h6 class="product-hed">Stone Name Here</h6>
                        <div class="price-bx">
                            <p class="del-price"><span>$</span>1250</p>
                            <!-- <p><span>$</span>127.6 - </p> -->
                            <p><span>$</span>125.25</p>
                        </div>

                    </div>
                </a>
            </div>

            <div class="product-bx">
                <a href="/detail">
                    <div class="product-bx-img" style="background-image: url('/img/gems2.jpg');">
                        <img src="/img/gems1.jpg" alt="">
                        <!-- <span class="discount-bx">-10%</span> -->
                        <div class="hot-stock-bx">
                            <!-- <span class="tagname-bx">Hot</span> -->
                            <!-- <span class="stock-bx">Out of Stock</span> -->
                        </div>
                    </div>
                </a>
                <div class="other-links">
                    <span><svg xmlns="http://www.w3.org/2000/svg" width="100" height="100" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="feather feather-shopping-bag"><path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"></path><line x1="3" y1="6" x2="21" y2="6"></line><path d="M16 10a4 4 0 0 1-8 0"></path></svg></span>
                    <span><svg xmlns="http://www.w3.org/2000/svg" width="100" height="100" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="feather feather-heart"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"></path></svg></span>
                    <span><svg xmlns="http://www.w3.org/2000/svg" width="100" height="100" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="feather feather-search"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg></span>
                </div>
                <a href="/detail">
                    <div class="product-bx-text">
                        <div class="start-rating-bx">
                            <div class="start-bx">
                                <svg class="active" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M480 208H308L256 48l-52 160H32l140 96-54 160 138-100 138 100-54-160z" fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="32"/></svg>
                                <svg class="active" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M480 208H308L256 48l-52 160H32l140 96-54 160 138-100 138 100-54-160z" fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="32"/></svg>
                                <svg class="active" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M480 208H308L256 48l-52 160H32l140 96-54 160 138-100 138 100-54-160z" fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="32"/></svg>
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M480 208H308L256 48l-52 160H32l140 96-54 160 138-100 138 100-54-160z" fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="32"/></svg>
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M480 208H308L256 48l-52 160H32l140 96-54 160 138-100 138 100-54-160z" fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="32"/></svg>
                            </div>
                            <span class="rating-num">(10 review)</span>
                        </div>
                        <h6 class="product-hed">Stone Name Here</h6>
                        <div class="price-bx">
                            <!-- <p class="del-price"><span>$</span>1250</p> -->
                            <!-- <p><span>$</span>127.6 - </p> -->
                            <p><span>$</span>125.25</p>
                        </div>

                    </div>
                </a>
            </div>

            <div class="product-bx">
                <a href="/detail">
                    <div class="product-bx-img" style="background-image: url('/img/gems3.jpg');">
                        <img src="/img/gems2.jpg" alt="">
                        <!-- <span class="discount-bx">-10%</span> -->
                        <div class="hot-stock-bx">
                            <span class="tagname-bx">Hot</span>
                            <!-- <span class="stock-bx">Out of Stock</span> -->
                        </div>
                    </div>
                </a>
                <div class="other-links">
                    <span><svg xmlns="http://www.w3.org/2000/svg" width="100" height="100" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="feather feather-shopping-bag"><path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"></path><line x1="3" y1="6" x2="21" y2="6"></line><path d="M16 10a4 4 0 0 1-8 0"></path></svg></span>
                    <span><svg xmlns="http://www.w3.org/2000/svg" width="100" height="100" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="feather feather-heart"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"></path></svg></span>
                    <span><svg xmlns="http://www.w3.org/2000/svg" width="100" height="100" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="feather feather-search"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg></span>
                </div>
                <a href="/detail">
                    <div class="product-bx-text">
                        <div class="start-rating-bx">
                            <div class="start-bx">
                                <svg class="active" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M480 208H308L256 48l-52 160H32l140 96-54 160 138-100 138 100-54-160z" fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="32"/></svg>
                                <svg class="active" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M480 208H308L256 48l-52 160H32l140 96-54 160 138-100 138 100-54-160z" fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="32"/></svg>
                                <svg class="active" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M480 208H308L256 48l-52 160H32l140 96-54 160 138-100 138 100-54-160z" fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="32"/></svg>
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M480 208H308L256 48l-52 160H32l140 96-54 160 138-100 138 100-54-160z" fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="32"/></svg>
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M480 208H308L256 48l-52 160H32l140 96-54 160 138-100 138 100-54-160z" fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="32"/></svg>
                            </div>
                            <span class="rating-num">(10 review)</span>
                        </div>
                        <h6 class="product-hed">Stone Name Here</h6>
                        <div class="price-bx">
                            <!-- <p class="del-price"><span>$</span>1250</p> -->
                            <!-- <p><span>$</span>127.6 - </p> -->
                            <p><span>$</span>125.25</p>
                        </div>

                    </div>
                </a>
            </div>

            <div class="product-bx">
                <a href="/detail">
                    <div class="product-bx-img" style="background-image: url('/img/gems.jpg');">
                        <img src="/img/gems1.jpg" alt="">
                        <!-- <span class="discount-bx">-10%</span> -->
                        <div class="hot-stock-bx">
                            <!-- <span class="tagname-bx">Hot</span> -->
                            <!-- <span class="stock-bx">Out of Stock</span> -->
                        </div>
                    </div>
                </a>
                <div class="other-links">
                    <span><svg xmlns="http://www.w3.org/2000/svg" width="100" height="100" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="feather feather-shopping-bag"><path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"></path><line x1="3" y1="6" x2="21" y2="6"></line><path d="M16 10a4 4 0 0 1-8 0"></path></svg></span>
                    <span><svg xmlns="http://www.w3.org/2000/svg" width="100" height="100" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="feather feather-heart"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"></path></svg></span>
                    <span><svg xmlns="http://www.w3.org/2000/svg" width="100" height="100" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="feather feather-search"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg></span>
                </div>
                <a href="/detail">
                    <div class="product-bx-text">
                        <div class="start-rating-bx">
                            <div class="start-bx">
                                <svg class="active" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M480 208H308L256 48l-52 160H32l140 96-54 160 138-100 138 100-54-160z" fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="32"/></svg>
                                <svg class="active" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M480 208H308L256 48l-52 160H32l140 96-54 160 138-100 138 100-54-160z" fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="32"/></svg>
                                <svg class="active" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M480 208H308L256 48l-52 160H32l140 96-54 160 138-100 138 100-54-160z" fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="32"/></svg>
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M480 208H308L256 48l-52 160H32l140 96-54 160 138-100 138 100-54-160z" fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="32"/></svg>
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M480 208H308L256 48l-52 160H32l140 96-54 160 138-100 138 100-54-160z" fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="32"/></svg>
                            </div>
                            <span class="rating-num">(10 review)</span>
                        </div>
                        <h6 class="product-hed">Stone Name Here</h6>
                        <div class="price-bx">
                            <!-- <p class="del-price"><span>$</span>1250</p> -->
                            <!-- <p><span>$</span>127.6 - </p> -->
                            <p><span>$</span>125.25</p>
                        </div>

                    </div>
                </a>
            </div>

            <div class="product-bx">
                <a href="/detail">
                    <div class="product-bx-img" style="background-image: url('/img/gems1.jpg');">
                        <img src="/img/gems2.jpg" alt="">
                        <!-- <span class="discount-bx">-10%</span> -->
                        <div class="hot-stock-bx">
                            <!-- <span class="tagname-bx">Hot</span> -->
                            <!-- <span class="stock-bx">Out of Stock</span> -->
                        </div>
                    </div>
                </a>
                <div class="other-links">
                    <span><svg xmlns="http://www.w3.org/2000/svg" width="100" height="100" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="feather feather-shopping-bag"><path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"></path><line x1="3" y1="6" x2="21" y2="6"></line><path d="M16 10a4 4 0 0 1-8 0"></path></svg></span>
                    <span><svg xmlns="http://www.w3.org/2000/svg" width="100" height="100" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="feather feather-heart"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"></path></svg></span>
                    <span><svg xmlns="http://www.w3.org/2000/svg" width="100" height="100" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="feather feather-search"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg></span>
                </div>
                <a href="/detail">
                    <div class="product-bx-text">
                        <div class="start-rating-bx">
                            <div class="start-bx">
                                <svg class="active" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M480 208H308L256 48l-52 160H32l140 96-54 160 138-100 138 100-54-160z" fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="32"/></svg>
                                <svg class="active" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M480 208H308L256 48l-52 160H32l140 96-54 160 138-100 138 100-54-160z" fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="32"/></svg>
                                <svg class="active" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M480 208H308L256 48l-52 160H32l140 96-54 160 138-100 138 100-54-160z" fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="32"/></svg>
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M480 208H308L256 48l-52 160H32l140 96-54 160 138-100 138 100-54-160z" fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="32"/></svg>
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M480 208H308L256 48l-52 160H32l140 96-54 160 138-100 138 100-54-160z" fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="32"/></svg>
                            </div>
                            <span class="rating-num">(10 review)</span>
                        </div>
                        <h6 class="product-hed">Stone Name Here</h6>
                        <div class="price-bx">
                            <!-- <p class="del-price"><span>$</span>1250</p> -->
                            <!-- <p><span>$</span>127.6 - </p> -->
                            <p><span>$</span>125.25</p>
                        </div>

                    </div>
                </a>
            </div>

        </div>
    </div>
</section>

<section class="container-lg mt-5 mb-5 legal-main px-3 px-sm-5">
    <div>
        <div class="row justify-content-center align-items-center">
            <div class="col-lg-4 col-md-6 mb-4">
                <img class="stone-gems-img" src="/img/gems-stone/garnet.png" alt="">
            </div>
            <div class="col-lg-8 col-md-6 mb-4">
                <h4 style='font-family: "Lato",sans-serif;font-size: 36px;'>Diamond</h4>
                <h5>Introduction</h5>
                <p>The World’s love for diamonds had its start in India where diamonds were gathered from the country’s rivers and streams. Some Historians estimate that
                India was trading in diamonds as early as the fourth century BC. Indian diamonds found their way to Europe. By the 1400’s , diamonds had become
                 fashionable accessories for Europe's elite. In the early 1700s India’s Diamond supplies began to decline, Brazil emerged as an important source of Diamond
                & things changed.</p>
                <p>India became the biggest Diamond cutting center. De beers started ruling diamond Market. De beers” Diamond are Forever” ad campaign made the
                Diamonds even more special,increased its demand in the market and in no time Diamonds became woman’s best friend.</p>
            </div>
        </div>


        <h5>Formation of Diamond</h5>
        <p>A Diamond has to go through a lot before it reaches the Jewelry display case. It forms deep in the earth under extreme heat and pressure. It is transported
        violently upward until it arrives at or near the earth’s surface. It's called Primary source of mining. Once they mine the rock then its cut and polished until its
        natural beauty shines through.</p>

        <h5>Colour</h5>
        <p>Diamond & color are hard to think together right? Most people think of diamonds that look colorless actually have a small amount of color - usually
        yellow or brown. Diamonds come in a startling array of other colors too. In fact, they come in just about every color of the rainbow.</p>

        <h5>Quality</h5>
        <p>The quality of diamonds is determined by four factors. Colour, cut, clarity and carat weight. A standardised assessing of diamond quality is known as The 4Cs
        of diamond quality. Read through our diamond introduction blog to get a detailed knowledge of Diamond 4c’s.</p>

        <h5>Healing properties</h5>
       <p>Diamonds are a symbol of purity. It brings love and a feeling of partnership and bonding in relationships. It brings strength and endurance to all energies and
        enhances the power of other crystals. This gem imparts fearlessness and fortitude. Diamonds are responsible for its ability to clear emotional and
        mental pain and bring about an onset to new beginnings.</p>
        <p>It purifies all the body systems, rebalances the metabolism and helps in regaining stamina. Helps in the treatment of allergies, glaucoma, dizziness and
        vertigo.</p>

        <h5>Conclusion</h5>
        <p>Diamond is the birthstone for the April month. Along with having a great value in the market, this stone also has good healing properties as well. Get in touch with us today to find
        out more about the kinds of diamond products we produce and design.</p>
    </div>
</section>


<?php
    require_once 'inc/footer.php';
?>