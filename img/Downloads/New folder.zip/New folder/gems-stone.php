<?php
    $pageId = "Gems-stone";
    $pageTitle = "Gems Stone";
    require_once 'inc/header.php';
?>

<section class="page-heding-bx" style="background-image: url(/img/bg-about.jpg);">
<!--  pagenavigationbar start  -->
<div class="custom-container pagenavigationbar">
    <p><a href="/">Home</a><span><i class="fa fa-angle-right" aria-hidden="true"></i></span><a class="active" href="javascript:void(0);">Gems Stone</a></p>
</div>
<!--  pagenavigationbar end  -->
    <h3 class="page-h3">Garnet</h3>
    <p class="page-p">January Birthstone</p>
</section>

<section class="pt-3 pb-5">
    <div class="container-lg mt-4 px-sm-4 px-2">
        <div class="product-slider owl-carousel owl-theme" id="hbdfhbdfrxh">

            <div class="product-bx">
                <a href="/detail">
                    <div class="product-bx-img" style="background-image: url('/img/gems1.jpg');">
                        <img src="/img/gems.jpg" alt="">
                        <!-- <span class="discount-bx">-10%</span> -->
                        <div class="hot-stock-bx">
                            <span class="tagname-bx">Hot</span>
                            <!-- <span class="stock-bx">Out of Stock</span> -->
                        </div>
                    </div>
                </a>
                <div class="other-links">
                    <span><svg xmlns="http://www.w3.org/2000/svg" width="100" height="100" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="feather feather-shopping-bag"><path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"></path><line x1="3" y1="6" x2="21" y2="6"></line><path d="M16 10a4 4 0 0 1-8 0"></path></svg></span>
                    <span><svg xmlns="http://www.w3.org/2000/svg" width="100" height="100" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="feather feather-heart"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"></path></svg></span>
                    <span><svg xmlns="http://www.w3.org/2000/svg" width="100" height="100" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="feather feather-search"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg></span>
                </div>
                <a href="/detail">
                    <div class="product-bx-text">
                        <div class="start-rating-bx">
                            <div class="start-bx">
                                <svg class="active" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M480 208H308L256 48l-52 160H32l140 96-54 160 138-100 138 100-54-160z" fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="32"/></svg>
                                <svg class="active" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M480 208H308L256 48l-52 160H32l140 96-54 160 138-100 138 100-54-160z" fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="32"/></svg>
                                <svg class="active" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M480 208H308L256 48l-52 160H32l140 96-54 160 138-100 138 100-54-160z" fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="32"/></svg>
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M480 208H308L256 48l-52 160H32l140 96-54 160 138-100 138 100-54-160z" fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="32"/></svg>
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M480 208H308L256 48l-52 160H32l140 96-54 160 138-100 138 100-54-160z" fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="32"/></svg>
                            </div>
                            <span class="rating-num">(10 review)</span>
                        </div>
                        <h6 class="product-hed">Stone Name Here</h6>
                        <div class="price-bx">
                            <p class="del-price"><span>$</span>1250</p>
                            <!-- <p><span>$</span>127.6 - </p> -->
                            <p><span>$</span>125.25</p>
                        </div>

                    </div>
                </a>
            </div>

            <div class="product-bx">
                <a href="/detail">
                    <div class="product-bx-img" style="background-image: url('/img/gems2.jpg');">
                        <img src="/img/gems1.jpg" alt="">
                        <!-- <span class="discount-bx">-10%</span> -->
                        <div class="hot-stock-bx">
                            <!-- <span class="tagname-bx">Hot</span> -->
                            <!-- <span class="stock-bx">Out of Stock</span> -->
                        </div>
                    </div>
                </a>
                <div class="other-links">
                    <span><svg xmlns="http://www.w3.org/2000/svg" width="100" height="100" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="feather feather-shopping-bag"><path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"></path><line x1="3" y1="6" x2="21" y2="6"></line><path d="M16 10a4 4 0 0 1-8 0"></path></svg></span>
                    <span><svg xmlns="http://www.w3.org/2000/svg" width="100" height="100" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="feather feather-heart"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"></path></svg></span>
                    <span><svg xmlns="http://www.w3.org/2000/svg" width="100" height="100" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="feather feather-search"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg></span>
                </div>
                <a href="/detail">
                    <div class="product-bx-text">
                        <div class="start-rating-bx">
                            <div class="start-bx">
                                <svg class="active" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M480 208H308L256 48l-52 160H32l140 96-54 160 138-100 138 100-54-160z" fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="32"/></svg>
                                <svg class="active" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M480 208H308L256 48l-52 160H32l140 96-54 160 138-100 138 100-54-160z" fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="32"/></svg>
                                <svg class="active" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M480 208H308L256 48l-52 160H32l140 96-54 160 138-100 138 100-54-160z" fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="32"/></svg>
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M480 208H308L256 48l-52 160H32l140 96-54 160 138-100 138 100-54-160z" fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="32"/></svg>
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M480 208H308L256 48l-52 160H32l140 96-54 160 138-100 138 100-54-160z" fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="32"/></svg>
                            </div>
                            <span class="rating-num">(10 review)</span>
                        </div>
                        <h6 class="product-hed">Stone Name Here</h6>
                        <div class="price-bx">
                            <!-- <p class="del-price"><span>$</span>1250</p> -->
                            <!-- <p><span>$</span>127.6 - </p> -->
                            <p><span>$</span>125.25</p>
                        </div>

                    </div>
                </a>
            </div>

            <div class="product-bx">
                <a href="/detail">
                    <div class="product-bx-img" style="background-image: url('/img/gems3.jpg');">
                        <img src="/img/gems2.jpg" alt="">
                        <!-- <span class="discount-bx">-10%</span> -->
                        <div class="hot-stock-bx">
                            <span class="tagname-bx">Hot</span>
                            <!-- <span class="stock-bx">Out of Stock</span> -->
                        </div>
                    </div>
                </a>
                <div class="other-links">
                    <span><svg xmlns="http://www.w3.org/2000/svg" width="100" height="100" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="feather feather-shopping-bag"><path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"></path><line x1="3" y1="6" x2="21" y2="6"></line><path d="M16 10a4 4 0 0 1-8 0"></path></svg></span>
                    <span><svg xmlns="http://www.w3.org/2000/svg" width="100" height="100" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="feather feather-heart"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"></path></svg></span>
                    <span><svg xmlns="http://www.w3.org/2000/svg" width="100" height="100" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="feather feather-search"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg></span>
                </div>
                <a href="/detail">
                    <div class="product-bx-text">
                        <div class="start-rating-bx">
                            <div class="start-bx">
                                <svg class="active" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M480 208H308L256 48l-52 160H32l140 96-54 160 138-100 138 100-54-160z" fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="32"/></svg>
                                <svg class="active" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M480 208H308L256 48l-52 160H32l140 96-54 160 138-100 138 100-54-160z" fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="32"/></svg>
                                <svg class="active" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M480 208H308L256 48l-52 160H32l140 96-54 160 138-100 138 100-54-160z" fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="32"/></svg>
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M480 208H308L256 48l-52 160H32l140 96-54 160 138-100 138 100-54-160z" fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="32"/></svg>
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M480 208H308L256 48l-52 160H32l140 96-54 160 138-100 138 100-54-160z" fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="32"/></svg>
                            </div>
                            <span class="rating-num">(10 review)</span>
                        </div>
                        <h6 class="product-hed">Stone Name Here</h6>
                        <div class="price-bx">
                            <!-- <p class="del-price"><span>$</span>1250</p> -->
                            <!-- <p><span>$</span>127.6 - </p> -->
                            <p><span>$</span>125.25</p>
                        </div>

                    </div>
                </a>
            </div>

            <div class="product-bx">
                <a href="/detail">
                    <div class="product-bx-img" style="background-image: url('/img/gems.jpg');">
                        <img src="/img/gems1.jpg" alt="">
                        <!-- <span class="discount-bx">-10%</span> -->
                        <div class="hot-stock-bx">
                            <!-- <span class="tagname-bx">Hot</span> -->
                            <!-- <span class="stock-bx">Out of Stock</span> -->
                        </div>
                    </div>
                </a>
                <div class="other-links">
                    <span><svg xmlns="http://www.w3.org/2000/svg" width="100" height="100" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="feather feather-shopping-bag"><path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"></path><line x1="3" y1="6" x2="21" y2="6"></line><path d="M16 10a4 4 0 0 1-8 0"></path></svg></span>
                    <span><svg xmlns="http://www.w3.org/2000/svg" width="100" height="100" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="feather feather-heart"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"></path></svg></span>
                    <span><svg xmlns="http://www.w3.org/2000/svg" width="100" height="100" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="feather feather-search"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg></span>
                </div>
                <a href="/detail">
                    <div class="product-bx-text">
                        <div class="start-rating-bx">
                            <div class="start-bx">
                                <svg class="active" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M480 208H308L256 48l-52 160H32l140 96-54 160 138-100 138 100-54-160z" fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="32"/></svg>
                                <svg class="active" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M480 208H308L256 48l-52 160H32l140 96-54 160 138-100 138 100-54-160z" fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="32"/></svg>
                                <svg class="active" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M480 208H308L256 48l-52 160H32l140 96-54 160 138-100 138 100-54-160z" fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="32"/></svg>
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M480 208H308L256 48l-52 160H32l140 96-54 160 138-100 138 100-54-160z" fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="32"/></svg>
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M480 208H308L256 48l-52 160H32l140 96-54 160 138-100 138 100-54-160z" fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="32"/></svg>
                            </div>
                            <span class="rating-num">(10 review)</span>
                        </div>
                        <h6 class="product-hed">Stone Name Here</h6>
                        <div class="price-bx">
                            <!-- <p class="del-price"><span>$</span>1250</p> -->
                            <!-- <p><span>$</span>127.6 - </p> -->
                            <p><span>$</span>125.25</p>
                        </div>

                    </div>
                </a>
            </div>

            <div class="product-bx">
                <a href="/detail">
                    <div class="product-bx-img" style="background-image: url('/img/gems1.jpg');">
                        <img src="/img/gems2.jpg" alt="">
                        <!-- <span class="discount-bx">-10%</span> -->
                        <div class="hot-stock-bx">
                            <!-- <span class="tagname-bx">Hot</span> -->
                            <!-- <span class="stock-bx">Out of Stock</span> -->
                        </div>
                    </div>
                </a>
                <div class="other-links">
                    <span><svg xmlns="http://www.w3.org/2000/svg" width="100" height="100" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="feather feather-shopping-bag"><path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"></path><line x1="3" y1="6" x2="21" y2="6"></line><path d="M16 10a4 4 0 0 1-8 0"></path></svg></span>
                    <span><svg xmlns="http://www.w3.org/2000/svg" width="100" height="100" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="feather feather-heart"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"></path></svg></span>
                    <span><svg xmlns="http://www.w3.org/2000/svg" width="100" height="100" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="feather feather-search"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg></span>
                </div>
                <a href="/detail">
                    <div class="product-bx-text">
                        <div class="start-rating-bx">
                            <div class="start-bx">
                                <svg class="active" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M480 208H308L256 48l-52 160H32l140 96-54 160 138-100 138 100-54-160z" fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="32"/></svg>
                                <svg class="active" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M480 208H308L256 48l-52 160H32l140 96-54 160 138-100 138 100-54-160z" fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="32"/></svg>
                                <svg class="active" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M480 208H308L256 48l-52 160H32l140 96-54 160 138-100 138 100-54-160z" fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="32"/></svg>
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M480 208H308L256 48l-52 160H32l140 96-54 160 138-100 138 100-54-160z" fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="32"/></svg>
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M480 208H308L256 48l-52 160H32l140 96-54 160 138-100 138 100-54-160z" fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="32"/></svg>
                            </div>
                            <span class="rating-num">(10 review)</span>
                        </div>
                        <h6 class="product-hed">Stone Name Here</h6>
                        <div class="price-bx">
                            <!-- <p class="del-price"><span>$</span>1250</p> -->
                            <!-- <p><span>$</span>127.6 - </p> -->
                            <p><span>$</span>125.25</p>
                        </div>

                    </div>
                </a>
            </div>

        </div>
    </div>
</section>

<section class="container-lg mt-5 mb-5 legal-main px-3 px-sm-5">
    <div>
        <div class="row justify-content-center align-items-center">
            <div class="col-lg-4 col-md-6 mb-4">
                <img class="stone-gems-img" src="/img/gems-stone/garnet.png" alt="">
            </div>
            <div class="col-lg-8 col-md-6 mb-4">
                <h4 style='font-family: "Lato",sans-serif;font-size: 36px;'>Garnet</h4>
                <h5>Introduction</h5>
                <p>Garnet has been mostly adorned by Egyptians & Ancient Rome. There are more than twenty varieties of Garnets. Out of which five varieties are in demand. Red garnets were amongst the most widely traded gems in 23 to 79 AD. Between 475 to 1450 AD Red garnets were favored by clergy and nobility. Its availability increased with the discovery of the famous Bohemian mine. Green garnet - Demantoid from Russias’ Ural Mountains and East African Tsavorites. Vibrant orange brownish Spessartite from Namibia and Nigeria are known as “Mandarin” garnets. Orange - cinnamon-colored variety of grossularite garnet’s Hessonite. Although this variety has not been much of a presence in the mainstream gem market, Mexico supplies good quality of hessonite.</p>
            </div>
        </div>
        <h5>What are Garnets?</h5>
        <p>Garnets are a group that includes a number of different minerals, so the appearance can vary widely. The first thing a buyer of garnets needs to be aware of is the wide variety of garnet types.</p>
        
        <p>At first, the sheer number of garnet varieties can seem bewildering. It helps to think of the different types of garnets in terms of color.</p>

        <h5>Color</h5>
        <p>Pyrope and almandine range in color from purple to orangy red. Spessartine is found in a variety of orange colors, while andradite comes in yellow and yellowish-green. Grossular has perhaps the widest color range of any garnet species, from colorless through yellow to reddish-orange and orangey-red, to a strong, vibrant green.</p>
        <p>Red Garnet is one of the most common and widespread gems wherein Green garnet Tsavorite is rarer because it needs an unusual rock. Spessartite, uncommon orange garnet is found in pegmatite veins which occur only occasionally.</p>
        <p>Out of all, Demantoid has been designers favorite choice during the Edwardian & Victorian periods. Inconsistent supply and continuing demand for demantoid keep the prices high.</p>
        <p>Spessartine is the most valuable orange garnet, and large, fine-quality stones are sold at a premium.Color-change garnets are valuable and sometimes sold at a higher rate. They are usually a mixture of pyrope-spessartine mixtures with vanadium as a coloring agent.</p>
        <p>People said that garnets light up the night and protect their owners from nightmares. Garnets have a history of protecting travelers against accidents far from home. Its stunning variety and rainbow of colors have made it a gift for all occasions.</p>

        <h5>What is Garnet good for?</h5>
        <p>Garnet is a spiritual stone of higher thinking and self-empowerment. It also denotes safety and strength. This stone symbolizes prosperity, abundance and also encourages gratitude and service to others. Garnet is considered a deeply spiritual stone.</p>
        <p>Healing powers of Garnets</p>
        <p>Farmer stimulate metabolism. They mainly help in treating spinal and cellular disorders, are energized and purifies the blood, heart, and lungs. Garnet can also regenerate DNA. Many people believe that Garnets not only help in physical healing but mental healing as well.</p>

        <h5>Conclusion</h5>
        <p>Garnets Rainbow color range gives a lot of options to choose from. Even If you are not born in January Garnet’s versability still offers you a lot!!</p>
        <p>Browse our Garnets Jewelry.</p>
    </div>
</section>


<?php
    require_once 'inc/footer.php';
?>